#ifndef LIBRARY_H
#define LIBRARY_H

#include "Book.h"
#include "Member.h"
#include "Transaction.h"
#include "FileManager.h"

class Library {
private:
    Book* books;
    Member* members;
    Transaction* transactions;

    int bookCount;
    int memberCount;
    int transactionCount;
    int capacity;

    FileManager fileMgr;

    int findBookIndex(int id) const;
    int findMemberIndex(int id) const;

public:
    Library(int cap = 100);
    ~Library();

    void addRecord();
    void displayRecords() const;
    void searchRecord() const;
    void updateRecord();
    void deleteRecord();
    void processMainTransaction();
    void generateReport() const;
    void saveData();
    void loadData();
};

#endif // LIBRARY_H