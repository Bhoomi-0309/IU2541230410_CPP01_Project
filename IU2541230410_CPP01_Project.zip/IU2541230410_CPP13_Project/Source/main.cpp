#include "Library.h"
#include <iostream>
#include <limits>

void displayMenu() {
    std::cout << "\n=========================================\n";
    std::cout << "   LIBRARY MANAGEMENT SYSTEM (IU2541230410)  \n";
    std::cout << "=========================================\n";
    std::cout << "1. Add Record\n";
    std::cout << "2. Display Records\n";
    std::cout << "3. Search Record\n";
    std::cout << "4. Update Record\n";
    std::cout << "5. Delete Record\n";
    std::cout << "6. Main Transaction/Process\n";
    std::cout << "7. Report\n";
    std::cout << "8. Save/Load\n";
    std::cout << "9. Exit\n";
    std::cout << "=========================================\n";
    std::cout << "Enter your choice (1-9): ";
}

int main() {
    Library system(100); // System object manages full business logic

    int choice = 0;
    while (true) {
        displayMenu();
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input! Please enter a number between 1 and 9.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1:
                system.addRecord();
                break;
            case 2:
                system.displayRecords();
                break;
            case 3:
                system.searchRecord();
                break;
            case 4:
                system.updateRecord();
                break;
            case 5:
                system.deleteRecord();
                break;
            case 6:
                system.processMainTransaction();
                break;
            case 7:
                system.generateReport();
                break;
            case 8:
                system.saveData();
                std::cout << "Data reloaded successfully!\n";
                system.loadData();
                break;
            case 9:
                system.saveData();
                std::cout << "Saving data and exiting program. Goodbye!\n";
                return 0;
            default:
                std::cout << "Invalid menu selection! Please choose between 1 and 9.\n";
                break;
        }
    }

    return 0;
}