#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "Book.h"
#include "Member.h"
#include "Transaction.h"
#include <string>

class FileManager {
private:
    std::string bookFilePath;
    std::string memberFilePath;
    std::string transactionFilePath;

    std::string resolvePath(const std::string& filename) const;

public:
    FileManager();
    ~FileManager();

    bool saveBooks(Book* books, int count);
    bool loadBooks(Book* books, int& count, int capacity);

    bool saveMembers(Member* members, int count);
    bool loadMembers(Member* members, int& count, int capacity);

    bool saveTransactions(Transaction* transactions, int count);
    bool loadTransactions(Transaction* transactions, int& count, int capacity);
};

#endif // FILEMANAGER_H