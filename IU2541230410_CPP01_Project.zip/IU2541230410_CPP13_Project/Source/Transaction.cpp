#include "Transaction.h"
#include <iostream>
#include <iomanip>

Transaction::Transaction() 
    : transactionID(0), memberID(0), bookID(0), issueDate("N/A"), returnDate("N/A"), status("UNKNOWN") {}

Transaction::Transaction(int tId, int mId, int bId, const std::string& iDate, const std::string& rDate, const std::string& status)
    : transactionID(tId), memberID(mId), bookID(bId), issueDate(iDate), returnDate(rDate), status(status) {}

Transaction::~Transaction() {}

int Transaction::getTransactionID() const { return transactionID; }
int Transaction::getMemberID() const { return memberID; }
int Transaction::getBookID() const { return bookID; }
std::string Transaction::getIssueDate() const { return issueDate; }
std::string Transaction::getReturnDate() const { return returnDate; }
std::string Transaction::getStatus() const { return status; }

void Transaction::markReturned(const std::string& date) {
    this->returnDate = date;
    this->status = "RETURNED";
}

void Transaction::displayTransaction() const {
    std::cout << std::left << std::setw(10) << transactionID
              << std::setw(12) << memberID
              << std::setw(10) << bookID
              << std::setw(15) << issueDate
              << std::setw(15) << returnDate
              << std::setw(12) << status
              << "\n";
}