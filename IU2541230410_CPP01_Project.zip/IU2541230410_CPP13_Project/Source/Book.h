#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    int bookID;
    std::string title;
    std::string author;
    bool isIssued;

public:
    Book();
    Book(int id, const std::string& title, const std::string& author, bool issued = false);
    ~Book();

    int getBookID() const;
    std::string getTitle() const;
    std::string getAuthor() const;
    bool getIsIssued() const;

    void setBookID(int id);
    void setTitle(const std::string& title);
    void setAuthor(const std::string& author);
    void setIsIssued(bool status);

    void display() const;
};

#endif // BOOK_H