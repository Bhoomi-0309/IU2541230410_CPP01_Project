#include "Book.h"
#include <iostream>
#include <iomanip>

Book::Book() : bookID(0), title("N/A"), author("N/A"), isIssued(false) {}

Book::Book(int id, const std::string& title, const std::string& author, bool issued)
    : bookID(id), title(title), author(author), isIssued(issued) {}

Book::~Book() {}

int Book::getBookID() const { return bookID; }
std::string Book::getTitle() const { return title; }
std::string Book::getAuthor() const { return author; }
bool Book::getIsIssued() const { return isIssued; }

void Book::setBookID(int id) { this->bookID = id; }
void Book::setTitle(const std::string& title) { this->title = title; }
void Book::setAuthor(const std::string& author) { this->author = author; }
void Book::setIsIssued(bool status) { this->isIssued = status; }

void Book::display() const {
    std::cout << std::left << std::setw(10) << bookID
              << std::setw(30) << title
              << std::setw(25) << author
              << std::setw(12) << (isIssued ? "ISSUED" : "AVAILABLE")
              << "\n";
}