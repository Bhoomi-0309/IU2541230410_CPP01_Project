#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
protected:
    int id;
    std::string name;
    std::string email;

public:
    Person();
    Person(int id, const std::string& name, const std::string& email);
    virtual ~Person();

    int getId() const;
    std::string getName() const;
    std::string getEmail() const;

    void setId(int id);
    void setName(const std::string& name);
    void setEmail(const std::string& email);

    // Pure virtual function for runtime polymorphism
    virtual void display() const = 0;
};

#endif // PERSON_H