#ifndef MEMBER_H
#define MEMBER_H

#include "Person.h"

class Member : public Person {
private:
    int maxBooksAllowed;
    int booksIssuedCount;

public:
    Member();
    Member(int id, const std::string& name, const std::string& email, int maxBooks = 3, int issuedCount = 0);
    ~Member() override;

    int getMaxBooksAllowed() const;
    int getBooksIssuedCount() const;

    void setMaxBooksAllowed(int maxBooks);
    void setBooksIssuedCount(int count);

    bool canBorrow() const;
    void incrementBooks();
    void decrementBooks();

    void display() const override;
};

#endif // MEMBER_H