#include "FileManager.h"
#include <fstream>
#include <sstream>
#include <iostream>

FileManager::FileManager() {
    bookFilePath = resolvePath("books.txt");
    memberFilePath = resolvePath("members.txt");
    transactionFilePath = resolvePath("transactions.txt");
}

FileManager::~FileManager() {}

// Smart path resolver: Checks if running from Root or inside Executable/ folder
std::string FileManager::resolvePath(const std::string& filename) const {
    std::ifstream test1("Data/" + filename);
    if (test1.good()) return "Data/" + filename;

    std::ifstream test2("../Data/" + filename);
    if (test2.good()) return "../Data/" + filename;

    // Default fallback
    return "Data/" + filename;
}

bool FileManager::saveBooks(Book* books, int count) {
    std::ofstream outFile(bookFilePath, std::ios::out | std::ios::trunc);
    if (!outFile.is_open()) {
        std::cerr << "Failed to open " << bookFilePath << " for writing.\n";
        return false;
    }

    for (int i = 0; i < count; ++i) {
        outFile << books[i].getBookID() << "|"
                << books[i].getTitle() << "|"
                << books[i].getAuthor() << "|"
                << books[i].getIsIssued() << "\n";
    }
    outFile.close();
    return true;
}

bool FileManager::saveMembers(Member* members, int count) {
    std::ofstream outFile(memberFilePath, std::ios::out | std::ios::trunc);
    if (!outFile.is_open()) {
        std::cerr << "Failed to open " << memberFilePath << " for writing.\n";
        return false;
    }

    for (int i = 0; i < count; ++i) {
        outFile << members[i].getId() << "|"
                << members[i].getName() << "|"
                << members[i].getEmail() << "|"
                << members[i].getMaxBooksAllowed() << "|"
                << members[i].getBooksIssuedCount() << "\n";
    }
    outFile.close();
    return true;
}

bool FileManager::saveTransactions(Transaction* transactions, int count) {
    std::ofstream outFile(transactionFilePath, std::ios::out | std::ios::trunc);
    if (!outFile.is_open()) {
        std::cerr << "Failed to open " << transactionFilePath << " for writing.\n";
        return false;
    }

    for (int i = 0; i < count; ++i) {
        outFile << transactions[i].getTransactionID() << "|"
                << transactions[i].getMemberID() << "|"
                << transactions[i].getBookID() << "|"
                << transactions[i].getIssueDate() << "|"
                << transactions[i].getReturnDate() << "|"
                << transactions[i].getStatus() << "\n";
    }
    outFile.close();
    return true;
}

bool FileManager::loadBooks(Book* books, int& count, int capacity) {
    std::ifstream inFile(bookFilePath);
    if (!inFile.is_open()) return false;

    count = 0;
    std::string line;
    while (std::getline(inFile, line) && count < capacity) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string idStr, title, author, issuedStr;

        if (std::getline(ss, idStr, '|') &&
            std::getline(ss, title, '|') &&
            std::getline(ss, author, '|') &&
            std::getline(ss, issuedStr)) {
            
            int id = std::stoi(idStr);
            bool issued = (std::stoi(issuedStr) == 1);
            books[count++] = Book(id, title, author, issued);
        }
    }
    inFile.close();
    return true;
}

bool FileManager::loadMembers(Member* members, int& count, int capacity) {
    std::ifstream inFile(memberFilePath);
    if (!inFile.is_open()) return false;

    count = 0;
    std::string line;
    while (std::getline(inFile, line) && count < capacity) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string idStr, name, email, maxStr, issuedStr;

        if (std::getline(ss, idStr, '|') &&
            std::getline(ss, name, '|') &&
            std::getline(ss, email, '|') &&
            std::getline(ss, maxStr, '|') &&
            std::getline(ss, issuedStr)) {
            
            int id = std::stoi(idStr);
            int maxBooks = std::stoi(maxStr);
            int issued = std::stoi(issuedStr);
            members[count++] = Member(id, name, email, maxBooks, issued);
        }
    }
    inFile.close();
    return true;
}

bool FileManager::loadTransactions(Transaction* transactions, int& count, int capacity) {
    std::ifstream inFile(transactionFilePath);
    if (!inFile.is_open()) return false;

    count = 0;
    std::string line;
    while (std::getline(inFile, line) && count < capacity) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string tIdStr, mIdStr, bIdStr, iDate, rDate, status;

        if (std::getline(ss, tIdStr, '|') &&
            std::getline(ss, mIdStr, '|') &&
            std::getline(ss, bIdStr, '|') &&
            std::getline(ss, iDate, '|') &&
            std::getline(ss, rDate, '|') &&
            std::getline(ss, status)) {
            
            transactions[count++] = Transaction(std::stoi(tIdStr), std::stoi(mIdStr), std::stoi(bIdStr), iDate, rDate, status);
        }
    }
    inFile.close();
    return true;
}