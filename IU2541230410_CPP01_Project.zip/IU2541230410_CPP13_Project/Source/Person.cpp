#include "Person.h"
#include <iostream>

Person::Person() : id(0), name("Unknown"), email("N/A") {}

Person::Person(int id, const std::string& name, const std::string& email)
    : id(id), name(name), email(email) {}

Person::~Person() {}

int Person::getId() const { return id; }
std::string Person::getName() const { return name; }
std::string Person::getEmail() const { return email; }

void Person::setId(int id) { this->id = id; }
void Person::setName(const std::string& name) { this->name = name; }
void Person::setEmail(const std::string& email) { this->email = email; }