#include "Member.h"
#include <iostream>
#include <iomanip>

Member::Member() : Person(), maxBooksAllowed(3), booksIssuedCount(0) {}

Member::Member(int id, const std::string& name, const std::string& email, int maxBooks, int issuedCount)
    : Person(id, name, email), maxBooksAllowed(maxBooks), booksIssuedCount(issuedCount) {}

Member::~Member() {}

int Member::getMaxBooksAllowed() const { return maxBooksAllowed; }
int Member::getBooksIssuedCount() const { return booksIssuedCount; }

void Member::setMaxBooksAllowed(int maxBooks) { this->maxBooksAllowed = maxBooks; }
void Member::setBooksIssuedCount(int count) { this->booksIssuedCount = count; }

bool Member::canBorrow() const { return booksIssuedCount < maxBooksAllowed; }

void Member::incrementBooks() { booksIssuedCount++; }
void Member::decrementBooks() { if (booksIssuedCount > 0) booksIssuedCount--; }

void Member::display() const {
    std::cout << std::left << std::setw(10) << id
              << std::setw(20) << name
              << std::setw(25) << email
              << std::setw(15) << (std::to_string(booksIssuedCount) + "/" + std::to_string(maxBooksAllowed))
              << "\n";
}