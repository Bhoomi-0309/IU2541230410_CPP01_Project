#include "Library.h"
#include <iostream>
#include <iomanip>
#include <limits>
#include <stdexcept>

Library::Library(int cap) : capacity(cap), bookCount(0), memberCount(0), transactionCount(0) {
    // Dynamic Memory Allocation
    books = new Book[capacity];
    members = new Member[capacity];
    transactions = new Transaction[capacity];

    loadData();
}

Library::~Library() {
    // Correct memory deallocation using delete[]
    delete[] books;
    delete[] members;
    delete[] transactions;
}

int Library::findBookIndex(int id) const {
    for (int i = 0; i < bookCount; ++i) {
        if (books[i].getBookID() == id) return i;
    }
    return -1;
}

int Library::findMemberIndex(int id) const {
    for (int i = 0; i < memberCount; ++i) {
        if (members[i].getId() == id) return i;
    }
    return -1;
}

void Library::addRecord() {
    std::cout << "\n--- ADD RECORD ---\n";
    std::cout << "1. Add Book\n2. Add Member\nChoice: ";
    int choice;
    if (!(std::cin >> choice)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Invalid input!\n";
        return;
    }

    if (choice == 1) {
        if (bookCount >= capacity) { std::cout << "Book storage full!\n"; return; }
        int id;
        std::string title, author;
        std::cout << "Enter Book ID: "; std::cin >> id;
        if (findBookIndex(id) != -1) { std::cout << "Book ID already exists!\n"; return; }
        std::cin.ignore();
        std::cout << "Enter Title: "; std::getline(std::cin, title);
        std::cout << "Enter Author: "; std::getline(std::cin, author);
        
        books[bookCount++] = Book(id, title, author);
        std::cout << "Book added successfully!\n";
    } else if (choice == 2) {
        if (memberCount >= capacity) { std::cout << "Member storage full!\n"; return; }
        int id;
        std::string name, email;
        std::cout << "Enter Member ID: "; std::cin >> id;
        if (findMemberIndex(id) != -1) { std::cout << "Member ID already exists!\n"; return; }
        std::cin.ignore();
        std::cout << "Enter Name: "; std::getline(std::cin, name);
        std::cout << "Enter Email: "; std::getline(std::cin, email);

        members[memberCount++] = Member(id, name, email);
        std::cout << "Member added successfully!\n";
    }
}

void Library::displayRecords() const {
    std::cout << "\n================ BOOK RECORDS ================\n";
    std::cout << std::left << std::setw(10) << "ID" << std::setw(30) << "Title" << std::setw(25) << "Author" << std::setw(12) << "Status" << "\n";
    std::cout << "---------------------------------------------------------------\n";
    for (int i = 0; i < bookCount; ++i) books[i].display();

    std::cout << "\n================ MEMBER RECORDS ================\n";
    std::cout << std::left << std::setw(10) << "ID" << std::setw(20) << "Name" << std::setw(25) << "Email" << std::setw(15) << "Issued/Max" << "\n";
    std::cout << "---------------------------------------------------------------\n";
    for (int i = 0; i < memberCount; ++i) {
        // Polymorphic call using base pointer
        const Person* p = &members[i];
        p->display();
    }
}

void Library::searchRecord() const {
    std::cout << "\n--- SEARCH RECORD ---\n";
    std::cout << "1. Search Book by ID\n2. Search Member by ID\nChoice: ";
    int choice, id;
    std::cin >> choice;
    std::cout << "Enter ID to search: ";
    std::cin >> id;

    if (choice == 1) {
        int idx = findBookIndex(id);
        if (idx != -1) books[idx].display();
        else std::cout << "Book not found!\n";
    } else if (choice == 2) {
        int idx = findMemberIndex(id);
        if (idx != -1) members[idx].display();
        else std::cout << "Member not found!\n";
    }
}

void Library::updateRecord() {
    std::cout << "\n--- UPDATE RECORD ---\n1. Update Book\n2. Update Member\nChoice: ";
    int choice, id;
    std::cin >> choice >> id;

    if (choice == 1) {
        int idx = findBookIndex(id);
        if (idx == -1) { std::cout << "Book not found!\n"; return; }
        std::string title, author;
        std::cin.ignore();
        std::cout << "Enter New Title: "; std::getline(std::cin, title);
        std::cout << "Enter New Author: "; std::getline(std::cin, author);
        books[idx].setTitle(title);
        books[idx].setAuthor(author);
        std::cout << "Book updated!\n";
    } else if (choice == 2) {
        int idx = findMemberIndex(id);
        if (idx == -1) { std::cout << "Member not found!\n"; return; }
        std::string name, email;
        std::cin.ignore();
        std::cout << "Enter New Name: "; std::getline(std::cin, name);
        std::cout << "Enter New Email: "; std::getline(std::cin, email);
        members[idx].setName(name);
        members[idx].setEmail(email);
        std::cout << "Member updated!\n";
    }
}

void Library::deleteRecord() {
    std::cout << "\n--- DELETE RECORD ---\n1. Delete Book\n2. Delete Member\nChoice: ";
    int choice, id;
    std::cin >> choice >> id;

    if (choice == 1) {
        int idx = findBookIndex(id);
        if (idx == -1) { std::cout << "Book not found!\n"; return; }
        for (int i = idx; i < bookCount - 1; ++i) books[i] = books[i + 1];
        bookCount--;
        std::cout << "Book deleted!\n";
    } else if (choice == 2) {
        int idx = findMemberIndex(id);
        if (idx == -1) { std::cout << "Member not found!\n"; return; }
        for (int i = idx; i < memberCount - 1; ++i) members[i] = members[i + 1];
        memberCount--;
        std::cout << "Member deleted!\n";
    }
}

void Library::processMainTransaction() {
    std::cout << "\n--- MAIN TRANSACTION PROCESS ---\n";
    std::cout << "1. Issue Book\n2. Return Book\nChoice: ";
    int choice;
    std::cin >> choice;

    int mId, bId;
    std::cout << "Enter Member ID: "; std::cin >> mId;
    std::cout << "Enter Book ID: "; std::cin >> bId;

    int mIdx = findMemberIndex(mId);
    int bIdx = findBookIndex(bId);

    if (mIdx == -1 || bIdx == -1) {
        std::cout << "Error: Member or Book ID invalid!\n";
        return;
    }

    std::string date;
    std::cout << "Enter Date (YYYY-MM-DD): "; std::cin >> date;

    if (choice == 1) { // Issue
        if (books[bIdx].getIsIssued()) {
            std::cout << "Error: Book is already issued!\n";
            return;
        }
        if (!members[mIdx].canBorrow()) {
            std::cout << "Error: Member reached borrowing limit!\n";
            return;
        }

        books[bIdx].setIsIssued(true);
        members[mIdx].incrementBooks();
        transactions[transactionCount++] = Transaction(transactionCount + 100, mId, bId, date, "N/A", "ISSUED");
        std::cout << "Book issued successfully!\n";
    } else if (choice == 2) { // Return
        if (!books[bIdx].getIsIssued()) {
            std::cout << "Error: Book is not currently issued!\n";
            return;
        }

        books[bIdx].setIsIssued(false);
        members[mIdx].decrementBooks();

        for (int i = 0; i < transactionCount; ++i) {
            if (transactions[i].getMemberID() == mId && transactions[i].getBookID() == bId && transactions[i].getStatus() == "ISSUED") {
                transactions[i].markReturned(date);
                break;
            }
        }
        std::cout << "Book returned successfully!\n";
    }
}

void Library::generateReport() const {
    std::cout << "\n================ SYSTEM REPORT ================\n";
    std::cout << "Total Books: " << bookCount << "\n";
    std::cout << "Total Members: " << memberCount << "\n";
    std::cout << "Total Transactions Recorded: " << transactionCount << "\n";
    std::cout << "-----------------------------------------------\n";
    std::cout << std::left << std::setw(10) << "TransID" << std::setw(12) << "MemID" << std::setw(10) << "BookID" << std::setw(15) << "Issue Date" << std::setw(15) << "Return Date" << std::setw(12) << "Status" << "\n";
    for (int i = 0; i < transactionCount; ++i) {
        transactions[i].displayTransaction();
    }
}

void Library::saveData() {
    bool b = fileMgr.saveBooks(books, bookCount);
    bool m = fileMgr.saveMembers(members, memberCount);
    bool t = fileMgr.saveTransactions(transactions, transactionCount);

    if (b && m && t) std::cout << "All data saved successfully to Data/ files!\n";
    else std::cout << "Warning: Error saving data files!\n";
}

void Library::loadData() {
    fileMgr.loadBooks(books, bookCount, capacity);
    fileMgr.loadMembers(members, memberCount, capacity);
    fileMgr.loadTransactions(transactions, transactionCount, capacity);
}