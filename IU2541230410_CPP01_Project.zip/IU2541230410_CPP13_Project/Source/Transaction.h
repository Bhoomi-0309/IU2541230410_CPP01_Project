#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>

class Transaction {
private:
    int transactionID;
    int memberID;
    int bookID;
    std::string issueDate;
    std::string returnDate;
    std::string status; // "ISSUED" or "RETURNED"

public:
    Transaction();
    Transaction(int tId, int mId, int bId, const std::string& iDate, const std::string& rDate = "N/A", const std::string& status = "ISSUED");
    ~Transaction();

    int getTransactionID() const;
    int getMemberID() const;
    int getBookID() const;
    std::string getIssueDate() const;
    std::string getReturnDate() const;
    std::string getStatus() const;

    void markReturned(const std::string& date);
    void displayTransaction() const;
};

#endif // TRANSACTION_H