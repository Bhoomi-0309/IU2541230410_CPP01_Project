========================================================================
                  LIBRARY MANAGEMENT SYSTEM (C++)
========================================================================

Student Enrollment Number: IU2541230410
Project Code: CPP01
Project Name: Library Management System
Language: C++ (Standard C++11 or later)

========================================================================
1. OVERVIEW
========================================================================
The Library Management System is an Object-Oriented C++ application designed
to streamline library operations including inventory tracking, member data
management, book issuing/returning transactions, and system reporting.

The system strictly follows standard Object-Oriented Programming (OOP)
principles, featuring base/derived inheritance, runtime polymorphism,
encapsulation, explicit dynamic memory management, exception handling, and
file persistence across sessions.

========================================================================
2. DIRECTORY & FILE STRUCTURE
========================================================================
IU2541230410_CPP01_Project/
├── Source/
│   ├── Person.h          (Base class declaration for human entities)
│   ├── Person.cpp        (Base class implementation)
│   ├── Member.h          (Derived class declaration for library members)
│   ├── Member.cpp        (Derived class implementation)
│   ├── Book.h            (Book entity class declaration)
│   ├── Book.cpp          (Book entity class implementation)
│   ├── Transaction.h     (Transaction entity class declaration)
│   ├── Transaction.cpp  (Transaction entity class implementation)
│   ├── FileManager.h     (File I/O manager header)
│   ├── FileManager.cpp   (File I/O manager implementation)
│   ├── Library.h         (Main system coordinator class header)
│   ├── Library.cpp       (Main system coordinator class implementation)
│   └── main.cpp          (Console driver and user menu handler)
├── Data/
│   ├── books.txt         (Pipe-delimited persistence store for books)
│   ├── members.txt       (Pipe-delimited persistence store for members)
│   └── transactions.txt  (Pipe-delimited persistence store for issue logs)
├── Diagrams/
│   ├── UseCaseDiagram.png
│   ├── ClassDiagram.png
│   ├── Sequence1_MainTransaction.png
│   └── Sequence2_SaveLoadProcess.png
├── Executable/
│   └── Project.exe       (Compiled binary application)
├── Screenshots/          (Console execution screenshots)
├── README.txt            (Project documentation & execution guide)
└── ProjectReport.pdf     (Comprehensive technical report)

========================================================================
3. KEY OOP CONCEPTS IMPLEMENTED
========================================================================
• Encapsulation: Private & protected data members with public accessors/mutators.
• Inheritance: Member class inherits attributes and methods from base Person class.
• Polymorphism: Pure virtual display() function in Person overridden in Member.
• Dynamic Memory: Array storage dynamically allocated with new[] and freed with delete[].
• Data Persistence: Custom file serialization/deserialization using fstream.
• Input Validation: Exception handling and stream checks against invalid user inputs.

========================================================================
4. COMPILATION INSTRUCTIONS
========================================================================
Using GCC / MinGW (Command Line):
1. Open terminal/command prompt and navigate to the project directory:
   cd IU2541230410_CPP01_Project

2. Compile all source files located in the Source/ folder:
   g++ -std=c++11 Source/*.cpp -o Executable/Project.exe

3. Run the compiled executable:
   Executable/Project.exe (or .\Executable\Project.exe on Windows)

Using IDEs (VS Code / Visual Studio / Code::Blocks / Dev-C++):
1. Create a new C++ Console project.
2. Add all files inside the Source/ directory to your project sources.
3. Ensure the workspace working directory contains the Data/ folder.
4. Build and Run the project (F5 / Ctrl+F5).

========================================================================
5. OPERATIONAL WORKFLOW & MAIN MENU
========================================================================
Upon launch, the system automatically loads record data from the Data/ folder.
Select options 1 through 9 from the interactive menu:

1. Add Record             - Register new Books or Members into the system.
2. Display Records        - View tabular lists of all Books and Members.
3. Search Record          - Search for a specific Book or Member by ID.
4. Update Record          - Edit details of existing Books or Members.
5. Delete Record          - Remove Books or Members from system memory.
6. Main Transaction       - Process Book Issue or Book Return transactions.
7. Report                 - Display full system activity and transaction logs.
8. Save/Load              - Manually save current state to files or refresh.
9. Exit                   - Auto-save all changes to Data/ and terminate.

========================================================================
6. VERIFYING DATA PERSISTENCE
========================================================================
1. Launch the program and add a new book or member (Option 1).
2. Perform a transaction (Option 6).
3. Exit the application using Option 9.
4. Open the files in Data/ to observe the newly recorded pipe-separated lines.
5. Relaunch the executable and select Option 2 to confirm data persistence.
========================================================================